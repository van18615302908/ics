#include "coro.h"

namespace coro {

static coroutine_env g_coro_env;

coroutine* create(func_t func, void* args) {
    // TODO: implement your code here
}

void release(coroutine* co) {
    // TODO: implement your code here
}

static void func_wrap(coroutine* co) {
    if (co->coro_func) {
        co->coro_func(co->args);
    }
    co->end = true;
    yield(-1);
}

int resume(coroutine* co, int param) {
    // TODO: implement your code here
}

int yield(int ret) {
    // TODO: implement your code here
}

}  // namespace coro