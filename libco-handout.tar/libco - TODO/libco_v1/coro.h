#pragma once

#include <ucontext.h>

#include <cassert>

namespace coro {

class coroutine;
using func_t = void (*)(void*);

coroutine* create(func_t func, void* args);
void release(coroutine* co);
int resume(coroutine* co, int param = 0);
int yield(int ret = 0);

struct coroutine {
    bool started = false;
    bool end = false;

    func_t coro_func = nullptr;
    void* args = nullptr;

    // TODO: add member variables you need

    ucontext_t ctx = {0};

    coroutine(func_t func, void* args) : coro_func(func), args(args) {
        /* TODO */
    }

    ~coroutine() {
        /* TODO */
    }
};

class coroutine_env {
private:
    // TODO: add member variables you need

public:
    coroutine_env() {
        // TODO: implement your code here
    }

    coroutine* get_coro(int idx) {
        // TODO: implement your code here
    }

    void push(coroutine* co) {
        // TODO: implement your code here
    }

    void pop() {
        // TODO: implement your code here
    }
};

}  // namespace coro