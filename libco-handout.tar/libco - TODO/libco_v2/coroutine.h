#pragma once

#include <cassert>
#include <cstdlib>

#include "coro_ctx.h"

namespace coro {

struct coroutine;
struct coroutine_attr;

coroutine *create(func_t coro_func, void *arg, const coroutine_attr *attr = nullptr);
void release(coroutine *co);

int resume(coroutine *co, int param = 0);
int yield(int ret = 0);

struct stack_mem {
    int stack_size = 0;  // 栈的大小
    // TODO: add member variables you need

    stack_mem(size_t size) : stack_size(size) {
        // TODO: implement your code here
    }

    ~stack_mem() {
        // TODO: implement your code here
    }
};

struct share_stack {
    // TODO: add member variables you need
    int count = 0;
    int stack_size = 0;
    stack_mem **stack_array = nullptr;

    share_stack(int count, size_t stack_size)
        : count(count), stack_size(stack_size) {
        // TODO: implement your code here
    }

    ~share_stack() {
        // TODO: implement your code here
    }

    stack_mem *get_stackmem() {
        // TODO: implement your code here
    }
};

struct coroutine {
    bool started = false;
    bool end = false;

    func_t coro_func = nullptr;
    void *arg = nullptr;

    // TODO: add member variables you need

    context ctx = {0};

    ~coroutine() {
        // TODO: implement your code here
    }
};

struct coroutine_attr {
    int stack_size = 128 * 1024;
    share_stack *sstack = nullptr;
};

class coroutine_env {
private:
    // TODO: add member variables you need

public:
    // TODO: add member variables you need

public:
    coroutine_env() {
        // TODO: implement your code here
    }

    coroutine *get_coro(int idx) {
        // TODO: implement your code here
    }

    void pop() {
        // TODO: implement your code here
    }

    void push(coroutine *co) {
        // TODO: implement your code here
    }
};

}  // namespace coro
