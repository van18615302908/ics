#include "coro_ctx.h"

#include <cstdint>
#include <cstring>

namespace coro {

void ctx_make(context* ctx, func_t coro_func, const void* arg) {
    // TODO: implement your code here
}

}  // namespace coro
