#include "coroutine.h"

#include <cstring>

namespace coro {

static coroutine_env g_coro_env;

extern "C" {
extern void coro_ctx_swap(context*, context*) asm("coro_ctx_swap");
};

coroutine* create(func_t coro_func, void* arg, const coroutine_attr* attr) {
    coroutine_attr at;
    if (attr != nullptr) {
        at = *attr;
    }

    // TODO: implement your code here

    return nullptr;
}

void release(coroutine* co) {
    // TODO: implement your code here
}

void save_stack(coroutine* co) {
    // TODO: implement your code here
}

void swap(coroutine* curr, coroutine* pending) {
    // TODO: implement your code here
}

static void func_wrap(coroutine* co) {
    if (co->coro_func) {
        co->coro_func(co->arg);
    }
    co->end = true;
    yield(-1);
}

int resume(coroutine* co, int param) {
    // TODO: implement your code here
    return -1;
}

int yield(int ret) {
    // TODO: implement your code here
    return -1;
}

}  // namespace coro
