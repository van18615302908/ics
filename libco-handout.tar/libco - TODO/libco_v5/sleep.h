#include <coroutine>
#include <functional>
#include <queue>
#include <thread>

namespace coro {

static std::queue<std::function<bool()>> task_queue;

struct sleep {
    sleep(int n_ms) : delay{n_ms} {}

    std::chrono::milliseconds delay;

    // TODO: add functions to make sleep be an awaitable object
};

struct Task {
    // TODO: add functions to make Task be an coroutine handle
};

void wait_task_queue_empty() {
    // TODO: block current thread until task queue is empty
}

}  // namespace coro
